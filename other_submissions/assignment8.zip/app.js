// NodeJS must be installed on your local machine
// Express and MongoDB must be installed from the terminal
const express = require('express');
const app = express();
const port = 3000, path = require('path');
app.use(express.json());

const { MongoClient } = require('mongodb');
var url = 'mongodb+srv://grader:odtGNWKJ3kmefAJL@cluster0.x8p9b.mongodb.net/';
const dbName = 'COMP322-Khamvanthong';
const client = new MongoClient(url);

client.connect(function() {
    console.log("Server connection successful");
    const db = client.db(dbName);

    // Create a new student document and add it into the "student" collection
    app.post('/api/student', (req, res) => {
        db.collection('student').findOne({stuID: student.stuID}, (result) => {
            if (result) res.status(400).send('Student ID already exists in the system');
            else {
                db.collection('student').insertOne(req.body, () => {
                    res.send('Student added to the system');
                });
            }
        });
    });

    // Find a student document by a student ID
    app.get('/api/student/:id', (req, res) => {
        const stuID = parseInt(req.params.id);
        db.collection('student').findOne({studentID: stuID}, (result) => {
            if (result) res.send(result);
            else res.status(404).send('Student not found');
        });
    });
    
    // Update a student document by a student ID
    app.put('/api/student/:id', (req, res) => {
        const studentID = parseInt(req.params.id);
        const newVals = { $set: req.body };
        db.collection('student').updateOne({stuId: studentID}, newVals, (result) => {
            if (result.matchedCount === 0) res.status(404).send('Cannot find student');
            else res.send('Student information has been updated');
        });
    });
    
    // Delete a student document by a student ID
    app.delete('/api/student/:id', (req, res) => {
        const studentID = parseInt(req.params.id);
        db.collection('student').deleteOne({ studentID: studentID }, (result) => {
            if (result.deletedCount === 0) res.status(404).send('Cannot find student');
            else res.send('Student has been deleted from the system');
        });
    });
});

// Send the packets of the student page to the client
app.get("/", (req, res) => res.sendFile(path.join(__dirname, 'student.html')));

// Use the command node app.js to run the server
app.listen(port, () => console.log(`Server is running http://localhost:${port}/`));