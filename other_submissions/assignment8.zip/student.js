// Add a student to the system
function addStudent() {
    const student = {
        fname: document.getElementById("fname").value,
        lname: document.getElementById("lname").value,
        stuId: parse(document.getElementById("stuId").value),
        address: document.getElementById("address").value,
        phone: document.getElementById("phone").value,
        email: document.getElementById("email").value
    };
    $.ajax({
        url: "/api/student",
        type: "POST",
        success: function() {
            document.getElementById('display').innerText = "Added student to the system";
        },
        error: function(err) {
            document.getElementById('display').innerText = 'Cannot add student';
            console.log(err);
        }
    });
}

// Find a student using their student ID
function getStuId() {
    const stuId = document.getElementById("stuId").value;
    //validateStudentID();
    $.ajax({
        url: "/api/student/:id",
        type: "GET",
        success: function() {
            document.getElementById('display').innerText = 'Student found';
        },
        error: function(err) {
            document.getElementById('display').innerText = 'Student not found';
            console.log(err);
        }
    });
}

// Update the student information using their student ID
function updateStuInfo() {
    const stuId = document.getElementById("stuId").value;
    const student = {
        fname: document.getElementById("fname").value,
        lname: document.getElementById("lname").value,
        address: document.getElementById("address").value,
        phone: document.getElementById("phone").value,
        email: document.getElementById("email").value
    };

    $.ajax({
        url: "/api/student/:id",
        type: "PUT",
        contentType: "application/json",
        data: JSON.stringify(student),
        success: function() {
            document.getElementById('display').innerText = "Student information has been updated";
        },
        error: function(err) {
            document.getElementById('display').innerText = 'Cannot update student';
            console.log(err);
        }
    });
}

// Delete a student from the system using their student ID
function deleteStu() {
    const stuId = document.getElementById("stuId").value;
    $.ajax({
        url: "/api/student/:id",
        type: "DELETE",
        success: function() {
            document.getElementById('display').innerText = "Student has been deleted from the system";
        },
        error: function(err) {
            document.getElementById('display').innerText = 'Cannot delete student';
            console.log(err);
        }
    });
}