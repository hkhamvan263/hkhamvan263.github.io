// NodeJS must be installed on your local machine
// ExpressJS must be installed through npm
// Can use VSCode for running the NodeJS server
// But, WebStorm is recommended for running the NodeJS server
const express = require('express'); // ExpressJS module for the REST API server
const app = express();
const port = 3000; // Default port number for the server
const path = require('path'); // Path module for file paths
app.use(express.json()); // Parse JSON data using Express

// Send the packets of the index page to the client
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// REST API for the grade resource
app.get("/grade", (req, res) => res.send('Got a GET request at /grade'));
app.put("/grade", (req, res) => res.send('Got a PUT request at /grade'));
app.post("/grade", (req, res) => res.send('Got a POST request at /grade'));
app.delete("/grade", (req, res) => res.send('Got a DELETE request at /grade'));

// Use the command node app.js in the terminal to run the REST API server
app.listen(port, () => console.log(`Server running at http://localhost:${port}/`));